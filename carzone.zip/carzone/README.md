# 🚗 CarZone – Flutter Car Marketplace App

A beautifully designed Flutter car marketplace app built from the CarZone Project Proposal.

## Project Structure

```
carzone/
├── lib/
│   ├── main.dart                    # App entry point
│   ├── models/
│   │   └── car.dart                 # Car data model
│   ├── data/
│   │   └── dummy_data.dart          # Phase 1 static dummy data (6 premium cars)
│   ├── screens/
│   │   ├── login_screen.dart        # Login with email/password
│   │   ├── signup_screen.dart       # New user registration
│   │   ├── home_screen.dart         # Car listing + search + filters
│   │   ├── car_detail_screen.dart   # Full car detail page
│   │   ├── favorites_screen.dart    # Saved/favorited cars
│   │   └── cart_screen.dart         # Cart + checkout summary
│   └── widgets/
│       └── car_card.dart            # Reusable car listing card
└── pubspec.yaml
```

## Features Implemented (Phase 1)

- ✅ Login Screen (email & password)
- ✅ Signup Screen (name, email, password)
- ✅ Home Screen with car listing
- ✅ Search by name, brand, or model
- ✅ Filter by brand and max price (bottom sheet)
- ✅ Car Detail Page with specs + description
- ✅ Add to Favorites (heart toggle)
- ✅ Add to Cart
- ✅ Favorites Screen
- ✅ Cart Screen with order summary
- ✅ Bottom navigation (Home / Favorites / Cart)

## Design

- **Theme**: Dark luxury aesthetic (`#0A0A0F` background)
- **Accent**: CarZone Red (`#E94560`)
- **Font**: Google Fonts – Outfit
- **Animations**: Fade + slide on login/signup, animated buttons

## Setup

```bash
# Install dependencies
flutter pub get

# Run the app
flutter run
```

## Dependencies

```yaml
google_fonts: ^6.1.0        # Outfit font
cached_network_image: ^3.3.1 # Car images from Unsplash
```

## Phase 2 (Next Steps)

- Firebase/Supabase backend integration
- Real authentication (JWT)
- Car data fetched from REST API
- Persistent cart & favorites (local storage)
- Real search with backend queries
