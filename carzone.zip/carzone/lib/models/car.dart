class Car {
  final String id;
  final String name;
  final String brand;
  final String model;
  final double price;
  final String imageUrl;
  final String description;
  final double rating;
  final int reviewCount;
  final String year;
  final String fuelType;
  final String transmission;
  final String mileage;
  final String engine;
  final List<String> colors;
  bool isFavorite;

  Car({
    required this.id,
    required this.name,
    required this.brand,
    required this.model,
    required this.price,
    required this.imageUrl,
    required this.description,
    this.rating = 4.5,
    this.reviewCount = 120,
    this.year = '2024',
    this.fuelType = 'Petrol',
    this.transmission = 'Automatic',
    this.mileage = '15 km/l',
    this.engine = '2.0L',
    this.colors = const ['#1a1a2e', '#e94560', '#f5f5f5'],
    this.isFavorite = false,
  });
}
