import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/car.dart';
import '../widgets/car_card.dart';
import 'car_detail_screen.dart';

class FavoritesScreen extends StatelessWidget {
  final List<Car> cars;
  final Function(String) onToggleFavorite;

  const FavoritesScreen({super.key, required this.cars, required this.onToggleFavorite});

  @override
  Widget build(BuildContext context) {
    final favorites = cars.where((c) => c.isFavorite).toList();
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Text('Favorites',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5)),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text('${favorites.length} saved cars',
                style: GoogleFonts.outfit(
                    color: Colors.white.withOpacity(0.4), fontSize: 13)),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: favorites.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.favorite_border_rounded,
                            size: 70, color: Colors.white.withOpacity(0.1)),
                        const SizedBox(height: 16),
                        Text('No favorites yet',
                            style: GoogleFonts.outfit(
                                color: Colors.white.withOpacity(0.4), fontSize: 18)),
                        const SizedBox(height: 8),
                        Text('Tap the heart icon to save cars',
                            style: GoogleFonts.outfit(
                                color: Colors.white.withOpacity(0.25), fontSize: 14)),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: favorites.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 16),
                    itemBuilder: (ctx, i) => CarCard(
                      car: favorites[i],
                      onTap: () => Navigator.push(ctx, MaterialPageRoute(
                          builder: (_) => CarDetailScreen(
                            car: favorites[i],
                            onToggleFavorite: () => onToggleFavorite(favorites[i].id),
                          ))),
                      onToggleFavorite: () => onToggleFavorite(favorites[i].id),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
