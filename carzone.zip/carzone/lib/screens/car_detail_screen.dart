import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/car.dart';

class CarDetailScreen extends StatefulWidget {
  final Car car;
  final VoidCallback onToggleFavorite;

  const CarDetailScreen({super.key, required this.car, required this.onToggleFavorite});

  @override
  State<CarDetailScreen> createState() => _CarDetailScreenState();
}

class _CarDetailScreenState extends State<CarDetailScreen> {
  bool _addedToCart = false;

  @override
  Widget build(BuildContext context) {
    final car = widget.car;
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 300,
                pinned: true,
                backgroundColor: const Color(0xFF0A0A0F),
                leading: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.4),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white, size: 18),
                  ),
                ),
                actions: [
                  GestureDetector(
                    onTap: () {
                      widget.onToggleFavorite();
                      setState(() {});
                    },
                    child: Container(
                      margin: const EdgeInsets.all(8),
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: car.isFavorite ? const Color(0xFFE94560) : Colors.black.withOpacity(0.4),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                          car.isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          color: Colors.white, size: 20),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        car.imageUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: const Color(0xFF1E1E2A),
                          child: const Icon(Icons.directions_car_rounded,
                              size: 80, color: Color(0xFF2E2E3A)),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              const Color(0xFF0A0A0F),
                              Colors.transparent,
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(car.name,
                                style: GoogleFonts.outfit(
                                    color: Colors.white,
                                    fontSize: 26,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    letterSpacing: -0.5)),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('\$${_formatPrice(car.price)}',
                                  style: GoogleFonts.outfit(
                                      color: const Color(0xFFE94560),
                                      fontSize: 24,
                                      fontWeight: FontWeight.w800)),
                              Text('Starting price',
                                  style: GoogleFonts.outfit(
                                      color: Colors.white.withOpacity(0.4), fontSize: 11)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Icon(Icons.star_rounded, color: const Color(0xFFF59E0B), size: 16),
                          const SizedBox(width: 4),
                          Text('${car.rating}',
                              style: GoogleFonts.outfit(
                                  color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                          const SizedBox(width: 6),
                          Text('(${car.reviewCount} reviews)',
                              style: GoogleFonts.outfit(
                                  color: Colors.white.withOpacity(0.4), fontSize: 13)),
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: car.fuelType == 'Electric'
                                  ? const Color(0xFF1A3D2B)
                                  : const Color(0xFF3D1A20),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(car.fuelType,
                                style: GoogleFonts.outfit(
                                    color: car.fuelType == 'Electric'
                                        ? const Color(0xFF2ECC71)
                                        : const Color(0xFFE94560),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),
                      // Specs grid
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: const Color(0xFF13131A),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withOpacity(0.06)),
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(child: _specItem(Icons.calendar_today_rounded, 'Year', car.year)),
                                Expanded(child: _specItem(Icons.settings_rounded, 'Transmission', car.transmission)),
                              ],
                            ),
                            const SizedBox(height: 20),
                            Row(
                              children: [
                                Expanded(child: _specItem(Icons.speed_rounded, 'Mileage', car.mileage)),
                                Expanded(child: _specItem(Icons.engineering_rounded, 'Engine', car.engine)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text('About This Car',
                          style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      Text(car.description,
                          style: GoogleFonts.outfit(
                              color: Colors.white.withOpacity(0.6),
                              fontSize: 14,
                              height: 1.7)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          // Bottom action buttons
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0A0F),
                border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06))),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        widget.onToggleFavorite();
                        setState(() {});
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                car.isFavorite ? 'Removed from favorites' : 'Added to favorites',
                                style: GoogleFonts.outfit()),
                            backgroundColor: const Color(0xFF13131A),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      child: Container(
                        height: 54,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1E1E2A),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                        ),
                        child: Center(
                          child: Icon(
                              car.isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                              color: const Color(0xFFE94560), size: 24),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 3,
                    child: GestureDetector(
                      onTap: () {
                        setState(() => _addedToCart = true);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('${car.name} added to cart!',
                                style: GoogleFonts.outfit()),
                            backgroundColor: const Color(0xFF13131A),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        height: 54,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: _addedToCart
                                  ? [const Color(0xFF27AE60), const Color(0xFF1E8449)]
                                  : [const Color(0xFFE94560), const Color(0xFFB5183A)]),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: (_addedToCart ? const Color(0xFF27AE60) : const Color(0xFFE94560))
                                  .withOpacity(0.4),
                              blurRadius: 16,
                              offset: const Offset(0, 6),
                            )
                          ],
                        ),
                        child: Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(_addedToCart ? Icons.check_rounded : Icons.shopping_cart_rounded,
                                  color: Colors.white, size: 20),
                              const SizedBox(width: 8),
                              Text(_addedToCart ? 'Added to Cart' : 'Add to Cart',
                                  style: GoogleFonts.outfit(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatPrice(double price) {
    return price.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
  }

  Widget _specItem(IconData icon, String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFFE94560), size: 20),
        const SizedBox(height: 8),
        Text(label,
            style: GoogleFonts.outfit(
                color: Colors.white.withOpacity(0.4), fontSize: 12)),
        const SizedBox(height: 2),
        Text(value,
            style: GoogleFonts.outfit(
                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
      ],
    );
  }
}
