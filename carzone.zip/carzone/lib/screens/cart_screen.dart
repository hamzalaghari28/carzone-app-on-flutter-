import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/car.dart';

class CartScreen extends StatelessWidget {
  final List<Car> cars;
  const CartScreen({super.key, required this.cars});

  @override
  Widget build(BuildContext context) {
    // For Phase 1, show a placeholder cart with one sample item
    final sample = cars.isNotEmpty ? cars.first : null;
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Text('My Cart',
                style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5)),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text('Review your selection',
                style: GoogleFonts.outfit(
                    color: Colors.white.withOpacity(0.4), fontSize: 13)),
          ),
          const SizedBox(height: 24),
          if (sample != null) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF13131A),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.06)),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        sample.imageUrl,
                        width: 90, height: 70,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 90, height: 70,
                          color: const Color(0xFF1E1E2A),
                          child: const Icon(Icons.directions_car_rounded,
                              color: Color(0xFF2E2E3A)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(sample.name,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.outfit(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600)),
                          const SizedBox(height: 4),
                          Text(sample.year,
                              style: GoogleFonts.outfit(
                                  color: Colors.white.withOpacity(0.4), fontSize: 13)),
                          const SizedBox(height: 8),
                          Text(
                            '\$${sample.price.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
                            style: GoogleFonts.outfit(
                                color: const Color(0xFFE94560),
                                fontSize: 16,
                                fontWeight: FontWeight.w800),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline_rounded,
                          color: Colors.white.withOpacity(0.3)),
                      onPressed: () {},
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF13131A),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Column(
                      children: [
                        _summaryRow('Subtotal', '\$${_formatPrice(sample.price)}'),
                        const SizedBox(height: 10),
                        _summaryRow('Taxes (8%)', '\$${_formatPrice(sample.price * 0.08)}'),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Divider(color: Colors.white.withOpacity(0.08)),
                        ),
                        _summaryRow(
                          'Total',
                          '\$${_formatPrice(sample.price * 1.08)}',
                          isTotal: true,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  GestureDetector(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Order placed successfully! 🎉',
                              style: GoogleFonts.outfit()),
                          backgroundColor: const Color(0xFF27AE60),
                        ),
                      );
                    },
                    child: Container(
                      width: double.infinity,
                      height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                            colors: [Color(0xFFE94560), Color(0xFFB5183A)]),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                              color: const Color(0xFFE94560).withOpacity(0.4),
                              blurRadius: 20,
                              offset: const Offset(0, 8)),
                        ],
                      ),
                      child: Center(
                        child: Text('Proceed to Checkout',
                            style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ] else
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.shopping_cart_outlined,
                        size: 70, color: Colors.white.withOpacity(0.1)),
                    const SizedBox(height: 16),
                    Text('Your cart is empty',
                        style: GoogleFonts.outfit(
                            color: Colors.white.withOpacity(0.4), fontSize: 18)),
                    const SizedBox(height: 8),
                    Text('Add cars from the listing page',
                        style: GoogleFonts.outfit(
                            color: Colors.white.withOpacity(0.25), fontSize: 14)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: GoogleFonts.outfit(
                color: isTotal ? Colors.white : Colors.white.withOpacity(0.5),
                fontSize: isTotal ? 16 : 14,
                fontWeight: isTotal ? FontWeight.w700 : FontWeight.w400)),
        Text(value,
            style: GoogleFonts.outfit(
                color: isTotal ? const Color(0xFFE94560) : Colors.white,
                fontSize: isTotal ? 18 : 14,
                fontWeight: FontWeight.w700)),
      ],
    );
  }

  String _formatPrice(double price) {
    return price.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
  }
}
