import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/car.dart';
import '../data/dummy_data.dart';
import '../widgets/car_card.dart';
import 'car_detail_screen.dart';
import 'favorites_screen.dart';
import 'cart_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchController = TextEditingController();
  String _selectedBrand = 'All';
  double _maxPrice = 300000;
  String _searchQuery = '';
  int _currentTab = 0;
  List<Car> _cars = List.from(dummyCars);

  List<Car> get _filteredCars {
    return _cars.where((car) {
      final matchesBrand = _selectedBrand == 'All' || car.brand == _selectedBrand;
      final matchesSearch = _searchQuery.isEmpty ||
          car.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          car.brand.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          car.model.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesPrice = car.price <= _maxPrice;
      return matchesBrand && matchesSearch && matchesPrice;
    }).toList();
  }

  void _showFilterSheet() {
    double tempPrice = _maxPrice;
    String tempBrand = _selectedBrand;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF13131A),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setS) {
          return Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                const SizedBox(height: 24),
                Text('Filters', style: GoogleFonts.outfit(
                    color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 24),
                Text('Brand', style: GoogleFonts.outfit(
                    color: Colors.white.withOpacity(0.6), fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: brands.map((b) {
                    final sel = tempBrand == b;
                    return GestureDetector(
                      onTap: () => setS(() => tempBrand = b),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: sel ? const Color(0xFFE94560) : const Color(0xFF1E1E2A),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: sel ? const Color(0xFFE94560) : Colors.white.withOpacity(0.1)),
                        ),
                        child: Text(b, style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Max Price', style: GoogleFonts.outfit(
                        color: Colors.white.withOpacity(0.6), fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('\$${tempPrice.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
                        style: GoogleFonts.outfit(
                            color: const Color(0xFFE94560), fontSize: 15, fontWeight: FontWeight.w700)),
                  ],
                ),
                SliderTheme(
                  data: SliderTheme.of(ctx).copyWith(
                    activeTrackColor: const Color(0xFFE94560),
                    inactiveTrackColor: Colors.white.withOpacity(0.1),
                    thumbColor: const Color(0xFFE94560),
                    overlayColor: const Color(0xFFE94560).withOpacity(0.2),
                  ),
                  child: Slider(
                    value: tempPrice,
                    min: 50000,
                    max: 300000,
                    divisions: 50,
                    onChanged: (v) => setS(() => tempPrice = v),
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _maxPrice = tempPrice;
                      _selectedBrand = tempBrand;
                    });
                    Navigator.pop(ctx);
                  },
                  child: Container(
                    width: double.infinity,
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xFFE94560), Color(0xFFB5183A)]),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Center(
                      child: Text('Apply Filters', style: GoogleFonts.outfit(
                          color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          );
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: _currentTab == 0 ? _buildHome() :
            _currentTab == 1 ? FavoritesScreen(cars: _cars, onToggleFavorite: (id) {
              setState(() {
                final i = _cars.indexWhere((c) => c.id == id);
                if (i != -1) _cars[i].isFavorite = !_cars[i].isFavorite;
              });
            }) :
            CartScreen(cars: _cars),
      bottomNavigationBar: _buildNavBar(),
    );
  }

  Widget _buildHome() {
    final filtered = _filteredCars;
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _buildHeader()),
          SliverToBoxAdapter(child: _buildSearchBar()),
          SliverToBoxAdapter(child: _buildBrandTabs()),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
              child: Text('${filtered.length} cars found',
                  style: GoogleFonts.outfit(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 13)),
            ),
          ),
          filtered.isEmpty
              ? SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off_rounded,
                            size: 60, color: Colors.white.withOpacity(0.2)),
                        const SizedBox(height: 12),
                        Text('No cars found',
                            style: GoogleFonts.outfit(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 16)),
                      ],
                    ),
                  ),
                )
              : SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (ctx, i) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: CarCard(
                          car: filtered[i],
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (_) => CarDetailScreen(
                                car: filtered[i],
                                onToggleFavorite: () {
                                  setState(() => filtered[i].isFavorite = !filtered[i].isFavorite);
                                },
                              ),
                            ));
                          },
                          onToggleFavorite: () {
                            setState(() => filtered[i].isFavorite = !filtered[i].isFavorite);
                          },
                        ),
                      ),
                      childCount: filtered.length,
                    ),
                  ),
                ),
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Good Morning 👋', style: GoogleFonts.outfit(
                  color: Colors.white.withOpacity(0.5), fontSize: 13)),
              Text('Find Your Dream Car', style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.5)),
            ],
          ),
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFE94560), Color(0xFFB5183A)]),
            ),
            child: const Icon(Icons.person_rounded, color: Colors.white, size: 22),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: const Color(0xFF16161E),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: TextField(
                controller: _searchController,
                onChanged: (v) => setState(() => _searchQuery = v),
                style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'Search brand, model...',
                  hintStyle: GoogleFonts.outfit(
                      color: Colors.white.withOpacity(0.3), fontSize: 14),
                  prefixIcon: Icon(Icons.search_rounded,
                      color: Colors.white.withOpacity(0.35), size: 20),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: Colors.white.withOpacity(0.35), size: 18),
                          onPressed: () => setState(() {
                            _searchController.clear();
                            _searchQuery = '';
                          }),
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: _showFilterSheet,
            child: Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFFE94560), Color(0xFFB5183A)]),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFFE94560).withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ],
              ),
              child: const Icon(Icons.tune_rounded, color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBrandTabs() {
    return SizedBox(
      height: 52,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
        itemCount: brands.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final b = brands[i];
          final sel = _selectedBrand == b;
          return GestureDetector(
            onTap: () => setState(() => _selectedBrand = b),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: sel ? const Color(0xFFE94560) : const Color(0xFF16161E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: sel ? const Color(0xFFE94560) : Colors.white.withOpacity(0.1)),
              ),
              child: Center(
                child: Text(b, style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildNavBar() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF13131A),
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      child: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (i) => setState(() => _currentTab = i),
        backgroundColor: Colors.transparent,
        elevation: 0,
        selectedItemColor: const Color(0xFFE94560),
        unselectedItemColor: Colors.white.withOpacity(0.35),
        selectedLabelStyle: GoogleFonts.outfit(fontSize: 11, fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.outfit(fontSize: 11),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_rounded), label: 'Favorites'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart_rounded), label: 'Cart'),
        ],
      ),
    );
  }
}
